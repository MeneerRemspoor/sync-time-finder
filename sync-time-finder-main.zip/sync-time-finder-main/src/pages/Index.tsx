
import TimezoneSync from "@/components/TimezoneSync";

const Index = () => {
  return <TimezoneSync />;
};

export default Index;
